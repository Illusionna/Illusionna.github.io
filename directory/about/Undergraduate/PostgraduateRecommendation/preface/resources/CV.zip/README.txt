我一共准备了 html 和 LaTeX 两套模板，夏令营用的是 HTML 样式，预推免用的是 LaTeX 样式。

【注意】LaTeX 模板使用  xelatex -synctex=1 -interaction=nonstopmode en.tex  编译，并建议 Window 11 + 的环境，因为 Windows 10 或者 Linux 以及 MacOS 可能缺少字体，编译  zh.tex  文件会报错。源文件可以浏览器搜索关键词：GitHub LaTeX Resume