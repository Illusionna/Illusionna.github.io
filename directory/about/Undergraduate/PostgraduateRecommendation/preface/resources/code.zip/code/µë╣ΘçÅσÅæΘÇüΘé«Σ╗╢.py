import os
import time
import json
import random
# >>> pip install yagmail
import yagmail


def cls() -> None:
    os.system('clear')
cls()


def RandomEmails(emails: dict) -> dict:
    items = list(emails.items())
    random.shuffle(items)
    return dict(items)


with open('./email/ICT.json', mode='r', encoding='utf-8') as f:
    data = RandomEmails(json.load(f))


class Config:
    SUBJECT = ['保研推免自荐', '计算所推免自荐+Illusionna', '推免自荐+Illusionna+XXXX大学', '保研自荐+Illusionna', '计算所硕士推免自荐+Illusionna', '中科院计算所推免自荐+Illusionna', '计算所推免自荐简历+Illusionna+信息与计算科学']
    DATA = data


def Send(name: str, field: str, address: str) -> None:
    # -----------------------------------------------------------------
    text = f"""
尊敬的{name}：

您好！很抱歉再次打扰您，前天给您发过一次邮件，一直没收到您的回复，很担心是否因为操作问题导致邮件没能被您成功接受，也不甘心就这般放弃，所以再次冒昧致信，望{name}海涵。
"""
    # -----------------------------------------------------------------
    text = f"""
尊敬的{name}：

您好，非常感谢您在百忙之中抽出宝贵时间阅读我的自荐信。

我在中科院计算所预推免的官网上看见您在招生，所以冒昧来信，想询问{name}您现在是否还有硕士招生名额？或者以后学院还有剩余名额，{name}也可以来信告知，我会一直恭候。

我叫 Illusionna，来自 XXXX 大学数学系的信息与计算科学专业，邮箱附件是我的个人简历，目前以专业推免第一的成绩获得保研资格。前段时间参加中科院的夏令营，就认为中科院学术氛围浓厚，师资力量强大。

在贵校官网了解到{name}您丰富的履历，以及对{field}方向的研究，对此很兴趣，因此{name}若还有招生名额并且有机会十推，我非常渴望能和您进一步交流（我的电话 136 XXXX 4889，我的微信 zoliomarling），倘若得到老师您的肯定认可，我一定会努力学习研究，不负期望。

学生本科是数学系的，深知自己在同计算机科班出身的同学相比，有不足，编程能力肯定有所不及，对老师您研究的前沿领域认知有局限，但学生认为我最大的优势在于数理逻辑以及很强的学习能力，喜欢钻研。如果有幸进入计算所学习，我一定会勤能补拙，务实务业，珍惜一切实践，不断提高自身能力。

再次感谢{name}在百忙之中阅读至此，冒昧致信，请您海涵。祝{name}身体健康，工作顺利，心想事成~ 顺颂秋祺 ：）
"""
    # -----------------------------------------------------------------
    contents = [text, './zh.pdf']
    try:
        yag = yagmail.SMTP(
            user = 'zoliomarling@gmail.com',
            # 浏览器搜索“QQ 邮箱 SMTP 协议授权口令”或者参考 https://senu.email
            password = 'xxxxxxxxxxxxxxxx',
            host = 'smtp.gmail.com'
        )
        yag.send(
            to = address,
            subject = Config.SUBJECT[random.randint(0, len(Config.SUBJECT) - 1)],
            contents = contents
        )
        print(f'\033[32m[*] 成功: {address}\033[0m')
    except:
        print(f'\033[31m[!] 失败: {address}\033[0m')



pos = 1
N = len(Config.DATA.values())
for key, value in Config.DATA.items():
    field = value[1]
    name = value[0][0] + '老师'
    print(f'{pos} / {N}', end='\t')
    Send(name=name, field=field, address=key)
    time.sleep(random.randint(45, 60))
    pos = -~pos