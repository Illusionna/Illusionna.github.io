import os
import re
import requests
from bs4 import BeautifulSoup


def cls() -> None:
    os.system('clear')
cls()


def IsEmail(x: str) -> bool:
    pattern = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
    if re.match(pattern, x):
        return True
    return False


url = 'https://iat.ustc.edu.cn/iat/x198/20240607/6961.html'
response = requests.get(url)

soup = BeautifulSoup(response.content, 'html.parser')

divs = soup.find_all('div', class_='news-detail-news-con')

L = []

for div in divs:
    table = div.find('table')
    if table:
        rows = table.find_all('tr')
        for row in rows:
            cols = row.find_all('td')
            for col in cols:
                L.append(col.text.strip())

L = L[10:]

emails = list(filter(lambda x: IsEmail(x), L))
print(emails)