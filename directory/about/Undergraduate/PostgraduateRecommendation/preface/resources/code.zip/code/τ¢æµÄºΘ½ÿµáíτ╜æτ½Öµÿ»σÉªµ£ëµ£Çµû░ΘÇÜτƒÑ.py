import os
import time
import json
import random
import hashlib
import logging
import yagmail
import requests


def cls() -> None:
    os.system('clear')
    os.makedirs('./data', exist_ok=True)
cls()


class Config:
    WEBSITE = {
        # '绿群 GitHub': 'https://raw.githubusercontent.com/CS-BAOYAN/CSYuTuiMian2024/main/README.md',
        '上交': 'https://yzb.sjtu.edu.cn/zsjz/ssszs.htm',
        '自动化所': 'http://ia.cas.cn/yjsjy/zs/sszs',
        # '川大': 'https://cs.scu.edu.cn/index/xytz.htm',
        '浙大': 'http://www.grs.zju.edu.cn/yjszs/28498/list.htm',
        '哈工大': 'https://yzb.hit.edu.cn/8822/list.htm',
        # '中山AI': 'https://sai.sysu.edu.cn/teach/graduate/index.htm',
        # '南大': 'https://yzb.nju.edu.cn/yw/48429/list.htm',
        '复旦': 'https://gsao.fudan.edu.cn',
        '西交CS': 'http://www.cs.xjtu.edu.cn/xwgg/tzgg.htm',
        '西交软': 'https://se.xjtu.edu.cn/xwgg/tzgg.htm',
        '西工大': 'https://yzb.nwpu.edu.cn/new/sszs/zsgg.htm',
        '北航CS': 'https://scse.buaa.edu.cn/xwgg/gggs.htm',
        '电子科大': 'https://yz.uestc.edu.cn/index/zytz.htm',
        '华东师范': 'https://yjszs.ecnu.edu.cn/43258/list.htm',
        '同济': 'https://yz.tongji.edu.cn/zsxw/ggtz.htm',
        '科学岛': 'https://www.hf.cas.cn/sbpy/yjsc/zs/sszs',
        '科大先研院': 'https://iat.ustc.edu.cn/iat/x198',
        '科大六系': 'https://eeis.ustc.edu.cn/2702/list.htm',
        '东北大学': 'http://yz.neu.edu.cn/5932/list.htm'
    }
    HEADERS = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.835.163 Safari/535.1'}


def RequestWeb(url: str) -> str:
    response = requests.get(url=url, headers=Config.HEADERS, verify=True)
    return hashlib.sha256(response.text.encode()).hexdigest()


def LoadJson(path: str) -> dict:
    """
    读取 json 字典.
    """
    with open(path, mode='r', encoding='utf-8') as f:
        data = json.load(f)
    return data


def WriteJson(path: str, data: dict) -> None:
    """
    把字典写入 json 文件.
    """
    with open(path, mode='w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)


def FindLatest() -> None:
    """
    找到最新的 json 文件.
    """
    return max(os.scandir('./data'), key=lambda x: x.stat().st_ctime).path


def Activate(process_start_time: str) -> dict:
    """
    启动程序.
    """
    if len(os.listdir('./data')) == 0:
        data = dict()
        for key, value in Config.WEBSITE.items():
            data[key] = RequestWeb(value)
        WriteJson(f'./data/{process_start_time}.json', data)
    else:
        data = LoadJson(FindLatest())
        data.update({k: RequestWeb(v) for k, v in Config.WEBSITE.items() if k not in data})
    return data


def Compare(A: dict, B: dict) -> list:
    """
    对比字典变化.
    """
    return [k for k, v in A.items() if k in B and v != B[k]]


def SendEmail(update: list) -> None:
    content = {key: Config.WEBSITE[key] for key in update if key in Config.WEBSITE}
    try:
        yag = yagmail.SMTP(
            user = 'zoliomarling@qq.com',
            password = 'xxxxxxxxxxxxxxxx',
            host = 'smtp.qq.com'
        )
        yag.send(
            to = 'zoliomarling@163.com',
            subject = '新公告: ' + ' + '.join(map(str, update)),
            contents = '\n\n'.join('{}: {}'.format(k, v) for k, v in content.items())
        )
        print(time.strftime('%Y-%m-%d %H:%M:%S'))
        print('\n'.join('{}: {}'.format(k, v) for k, v in content.items()))
        print('')
        logging.info(update)
    except:
        print(time.strftime('%Y-%m-%d %H:%M:%S'))
        print('发送失败')
        logging.info('发送失败')
        print('')


def Detect(initial_data: dict, interval: int) -> None:
    """
    监测.
    """
    logging.basicConfig(
        filename = './update.log',
        level = logging.INFO,
        format ='%(asctime)s - %(message)s',
        datefmt = '%Y-%m-%d %H:%M:%S'
    )
    while True:
        current_data = dict()
        for key, value in Config.WEBSITE.items():
            current_data[key] = RequestWeb(value)
        update = Compare(initial_data, current_data)
        if len(update) != 0:
            initial_data = current_data
            WriteJson(f"./data/{time.strftime('%Y-%m-%d+%H')}.json", current_data)
            SendEmail(update)
        else:
            WriteJson(f"./data/{time.strftime('%Y-%m-%d+%H')}.json", current_data)
        time.sleep(int(interval * (1 + random.random())))


if __name__ == '__main__':
    process_start_time = time.strftime('%Y-%m-%d+%H')
    print(f'\033[32m* {time.strftime("%Y-%m-%d %H:%M:%S")} 监听开启...\033[0m')
    data = Activate(process_start_time)
    Detect(data, 60 * 30)