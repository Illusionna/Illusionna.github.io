import os
import re
import json
import subprocess
import urllib.parse
from bs4 import BeautifulSoup

def cls() -> None:
    os.system('clear')
cls()

def curl(url: str) -> str:
    process = subprocess.run(['curl', url], capture_output=True, text=True)
    return process.stdout

def parse(html: str) -> list[dict]:
    content = html
    soup = BeautifulSoup(content, 'html.parser')
    number_list = list()
    for li in soup.find_all('li'):
        img_tag = li.find('img')
        link_tag = li.find('a')
        if img_tag and link_tag:
            number_list.append(
                {
                    'href': link_tag['href'],
                    'name': link_tag.text.strip()
                }
            )
    return number_list

def excavate(url: str, numbers: list[dict]) -> list[dict]:
    ans = list()
    for i in numbers:
        ans.append({'name': i['name'], 'url': urllib.parse.urljoin(url, i['href'])})
    return ans

def field(html: str) -> str:
    try:
        lines = html.splitlines()
        for line in lines:
            if 'var yjfx' in line:
                start_index = line.find('var yjfx=') + len('var yjfx=')
                end_index = line.find(';', start_index)
                yjfx_content = line[start_index:end_index].strip().replace('"', '').replace("'", "")
                return yjfx_content
        return 'NULL'
    except:
        return 'NULL'

def detail(pages: list[dict]) -> dict:
    ans = dict()
    for page in pages:
        html = curl(page['url'])
        soup = BeautifulSoup(html, 'html.parser')
        email = soup.find('b', id='dzyj')
        direction = field(html)
        if email:
            email = email.find_next_sibling('span').text.strip()
        else:
            email = ''
        ans[email] = [page['name'], re.sub(re.compile(r'<.*?>'), '', direction)]
    return ans

data = dict()
X = ['http://www.ict.ac.cn/yjdw/yjy2020/index.html']
for i in range(1, 5, 1):
    X.append(f'http://www.ict.ac.cn/yjdw/yjy2020/index_{i}.html')

for x in X:
    pages = excavate(x, parse(curl(x)))
    data.update(detail(pages))

with open('./ICT.json', mode='w', encoding='utf-8') as f:
    f.write(
        json.dumps(
            data,
            indent=4,
            ensure_ascii=False
        )
    )