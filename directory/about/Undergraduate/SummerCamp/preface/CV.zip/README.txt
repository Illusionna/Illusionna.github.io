我一共准备了 html 和 LaTeX 两套模板，最后申请夏令营的时候，采用了 html 打印样式的简历。

【注意】LaTeX 模板使用 xelatex -synctex=1 -interaction=nonstopmode en?zh.tex 编译，并建议 Window 11 + 的环境。