import ctypes
import platform
import numpy as np
from PIL import Image

print("\033[H\033[J", end='')

OS = {
    'Darwin': 'dylib',
    'Linux': 'so',
    'Windows': 'dll'
}[platform.system()]

lib = ctypes.CDLL(f'./utils/Osrrceoy.{OS}')
lib.__getattr__('BinaryErrorProcess')
lib.BinaryErrorProcess.argtypes = [
    ctypes.POINTER(ctypes.POINTER(ctypes.c_int)),
    ctypes.c_int,
    ctypes.c_int,
    ctypes.c_float
]
lib.BinaryErrorProcess.restype =  ctypes.POINTER(ctypes.POINTER(ctypes.c_int))

matrix: list = np.array(Image.open('./data/LowNoise.png').convert('1')).astype(int).tolist()

dim1 = len(matrix)
dim2 = len(matrix[0])
r = 0.6

arrs = (ctypes.POINTER(ctypes.c_int) * len(matrix))()
for i, row in enumerate(matrix):
    arrs[i] = ctypes.cast(
        (ctypes.c_int * len(row))(*row),
        ctypes.POINTER(ctypes.c_int)
    )
ans = lib.BinaryErrorProcess(arrs, dim1, dim2, r)

result = np.array([[ans[i][j] for j in range(dim2)] for i in range(dim1)])
print(result)
Image.fromarray(result.astype(np.uint8)).show()