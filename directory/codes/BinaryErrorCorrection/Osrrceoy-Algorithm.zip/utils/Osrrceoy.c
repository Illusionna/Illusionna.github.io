/*
Windows >>> gcc --shared -o ./utils/Osrrceoy.dll ./utils/Osrrceoy.c
Linux >>> gcc --shared -o ./utils/Osrrceoy.so ./utils/Osrrceoy.c
macOS >>> gcc --shared -o ./utils/Osrrceoy.dylib ./utils/Osrrceoy.c
*/

# include <stdlib.h>

int AscendingOrder(const void * a, const void * b) {
    return *(int*)a - *(int*)b;
}

int** BinaryErrorProcess(int** matrix, int dim1, int dim2, float r) {
    // 矩阵拉直.
    int* vectorX = (int*)malloc(dim1 * dim2 * sizeof(int));
    for (int i=0; i < dim1; ++i) {
        for (int j=0; j < dim2; ++j) {
            vectorX[i * dim2 + j] = matrix[i][j];
        }
    }

    // 寻找第一个 1 元素和最后一个 1 元素的索引.
    int first_one = -1;
    int last_one = -1;
    for (int i = 0; i < dim1 * dim2; ++i) {
        if (vectorX[i] == 1) {
            first_one = i;
            break;
        }
    }
    for (int i = dim1 * dim2 - 1; i >= 0; i--) {
        if (vectorX[i] == 1) {
            last_one = i;
            break;
        }
    }
    if (first_one >= last_one) {
        // 矩阵保持不动, 直接返回原矩阵.
        return matrix;
    }

    // 统计连续零元素分布个数.
    int* MX = NULL;
    int MX_size = 0;
    int zero_nums = 0;
    for (int i=0; i <= dim1 * dim2; ++i) {
        if ((i == dim1 * dim2) || (vectorX[i] != 0)) {
            if (zero_nums > 0) {
                MX = (int*)realloc(MX, (MX_size + 1) * sizeof(int));
                MX[MX_size++] = zero_nums;
            }
            zero_nums = 0;
        } else {
            ++zero_nums;
        }
    }

    //  连续零元素数组从小到大排序.
    int* NX = (int*)malloc(MX_size * sizeof(int));
    for (int i=0; i < MX_size; ++i) NX[i] = MX[i];
    qsort(NX, MX_size, sizeof(int), AscendingOrder);

    // 计算最小文本长度.
    float MLT = 0;
    for (int i=0; i < (int) (r * MX_size); ++i) {
        MLT = MLT + NX[i];
    }
    MLT = MLT / (int) (r * MX_size);

    // 计算新的 vec'(X) 向量.
    int pos = 0;
    while (++first_one <= last_one) {
        if (vectorX[first_one] == 0) {
            int m = MX[pos++];
            int skip = m;
            if (m <= MLT) {
                while (m-- > 0) {
                    vectorX[first_one + m] = 1;
                }
                first_one = first_one + skip;
            } else {
                first_one = first_one + m;
            }
        }
    }

    // 向量压缩还原矩阵.
    for (int i=0; i < dim1; ++i) {
        for (int j=0; j < dim2; ++j) {
            matrix[i][j] = 255 * vectorX[i * dim2 + j];
        }
    }

    free(MX);
    free(NX);
    free(vectorX);
    return matrix;
}