'''
System --> macOS & Python 3.10.0
File ----> main.py
Author --> Illusionna
Create --> 2024-12-10 21:18:47
Website -> https://orzzz.net
'''


import os
import re
import torch
import random
import platform
import itertools


def cls() -> None:
    os.system('')
    try:
        os.system(
            {'Windows': 'cls', 'Linux': 'clear', 'Darwin': 'clear'}[platform.system()]
        )
    except:
        print('\033[H\033[J', end='')
cls()


class NNLM(torch.nn.Module):
    """
    `NNLM` 类根据论文 "A Neural Probabilistic Language Model (2003)" 公式编写.
    """

    def __init__(self, V: int, m: int, h: int, n: int, *args, **kwargs) -> None:
        """
        V: 词汇字典所含元素个数.
        m: 用向量表达单词, 向量的维度.
        h: 隐藏层神经元个数.
        n: 已知前 n-1 个单词, 推理接下来第 n 个单词, 论文中 n 的最小索引从 1 开始.
        """
        super().__init__(*args, **kwargs)
        self.b = torch.nn.Parameter(torch.randn(V))   # 偏置 b 是模型输出层的自由参数, 标准正态.
        self.d = torch.nn.Parameter(torch.randn(h))   # 隐藏层偏置 d 有 h 个元素, 标准正态.
        self.W = torch.nn.Parameter(torch.rand(V, (n-1)*m))  # 单词特征层到输出层权重, 均匀分布.
        self.U = torch.nn.Parameter(torch.rand(V, h))    # 隐藏层到输出层权重, 均匀分布.
        self.H = torch.nn.Parameter(torch.rand(h, (n-1)*m))  # 隐藏层权重, 均匀分布.
        self.C = torch.nn.Embedding(num_embeddings=V, embedding_dim=m)   # 词嵌入矩阵.
        # θ = (b, d, W, U, H, C)
        self.__dict__.update(**locals())

    def forward(self, x: torch.LongTensor) -> torch.Tensor:
        # x = (C(w_{t-1}), C(w_{t-2}), ..., C(w_{t-n+1}))
        # 单词特征层激活的向量, 来自于词嵌入矩阵 C 所有结果的拼接.
        x = self.C(x)
        x = x.view(-1, (self.n-1)*self.m)

        # y = b + Wx + Utanh(d + Hx)
        # 输出结果是没有归一化的对数概率, 此处好像有 "残差网络" 的思想.
        y = self.b + torch.matmul(x, self.W.T) + torch.matmul(torch.tanh(self.d + torch.matmul(x, self.H.T)), self.U.T)
        return y


def tokenizer(sentence: str) -> list[str]:
    """
    移除句子的所有标点符号, 并小写, 最后去除空白, 形成 token 列表.

    >>> s = 'Down with     ;; the Vikings. ! '
    >>> tokenizer(s, 3)
    >>> ['down', 'with', 'the', 'vikings']
    """
    return re.sub(r'[^\w\s]', '', sentence).lower().split()


def dictionary(dataset: list[list[str]]) -> tuple[dict]:
    """
    生成词汇索引字典、索引词汇字典.

    >>> dataset = [
        ['the', 'cat', 'is', 'walking', 'in', 'the', 'bedroom'],
        ['a', 'dog', 'was', 'running', 'in', 'a', 'room']
    ]
    >>> dictionary(dataset)
    >>> (
        {'the': 0, 'a': 1, 'cat': 2, 'bedroom': 3, 'dog': 4, 'room': 5, 'is': 6, 'running': 7, 'walking': 8, 'was': 9, 'in': 10},
        {0: 'the', 1: 'a', 2: 'cat', 3: 'bedroom', 4: 'dog', 5: 'room', 6: 'is', 7: 'running', 8: 'walking', 9: 'was', 10: 'in'}
    )
    """
    words = set(itertools.chain.from_iterable(dataset))
    vocabulary_index = dict()
    index_vocabulary = dict()
    for key, value in enumerate(words):
        vocabulary_index[value] = key
        index_vocabulary[key] = value
    return vocabulary_index, index_vocabulary


def train_test_split(dataset: list, test_size: int) -> tuple[list]:
    """
    训练集、测试集划分.

    >>> x = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
    >>> train_test_split(x, 0.3)
    >>> ([5, 0, 4, 2, 8, 6, 3], [7, 9, 1])
    """
    if not (0 < test_size < 1):
        raise ValueError('测试集比例必须介于 0 ~ 1 之间')
    random.shuffle(dataset)
    test_size = int(len(dataset) * test_size)
    test = dataset[:test_size]
    train = dataset[test_size:]
    return train, test


# ------------------------------------------------
n = 8
epoch = 100
device = torch.device(
    'mps' if platform.system() == 'Darwin'
    else ('cuda' if torch.cuda.is_available() else 'cpu')
)
# ------------------------------------------------

dataset: list[list[str]] = []

with open('./data.txt', mode='r', encoding='utf-8') as f:
    while True:
        line = f.readline()
        if not line:
            break
        if line.strip():
            dataset.append(tokenizer(line.strip()))

vocabulary_index, index_vocabulary = dictionary(dataset)
train, test = train_test_split(dataset, 0.01)

model = NNLM(V=len(vocabulary_index), m=5, h=12, n=n).to(device)
criterion = torch.nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

sentences_x = [item[:(n-1)] for item in train]
sentences_target = [item[n-1] for item in train]

x = torch.LongTensor([[vocabulary_index.get(j) for j in i] for i in sentences_x]).to(device)
target = torch.LongTensor([vocabulary_index.get(i) for i in sentences_target]).to(device)

for _ in range(0, epoch, 1):
    optimizer.zero_grad()
    y = model.forward(x)
    loss = criterion(y, target)
    if _ % 25 == 0:
        print(f'[{_ + 25} / {epoch}]\tloss = {loss:.7f}')
    loss.backward()
    optimizer.step()

print('------------------------------------------------')

unknown = torch.LongTensor([[vocabulary_index.get(j) for j in i] for i in list(item[:(n-1)] for item in test)]).to(device)

y: torch.Tensor = model(unknown)
predict = y.max(dim=1, keepdim=True)[1].squeeze()

for idx, i in enumerate(test):
    print(' '.join(i[:(n-1)]) + f'\033[32m [ {i[n-1]} \033[0m' + '/' + f'\033[33m {index_vocabulary.get(int(predict[idx]))} ] \033[0m' + ' '.join(i[(n):]))