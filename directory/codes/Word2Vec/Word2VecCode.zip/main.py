'''
# System --> Windows & Python3.10.0
# File ----> main.py
# Author --> Illusionna
# Create --> 2024/12/15 23:26:14
'''
# -*- Encoding: UTF-8 -*-


import os
import torch
import platform
import itertools
import matplotlib.pyplot as plt


def cls() -> None:
    os.system('')
    try:
        os.system(
            {'Windows': 'cls', 'Linux': 'clear', 'Darwin': 'clear'}[platform.system()]
        )
    except:
        print('\033[H\033[J', end='')
cls()


class SkipGram(torch.nn.Module):
    def __init__(self, n: int, m: int, *args, **kwargs) -> None:
        """_summary_

        Args:
            n (int): 词汇索引表大小
            m (int): 是词向量维度, 即一个单词具备的属性个数
        """
        super().__init__(*args, **kwargs)
        self.C = torch.nn.Embedding(n, m)
        self.hidden_layer = torch.nn.Linear(m, 128, bias=False)
        self.output_layer = torch.nn.Linear(128, n, bias=False)

    def forward(self, x: torch.LongTensor) -> torch.Tensor:
        y = self.C(x)
        y = torch.nn.functional.relu(self.hidden_layer(y))
        y = torch.nn.functional.log_softmax(self.output_layer(y), dim=1)
        return y


def tokenizer(dataset_path: str, window_size: int) -> tuple[list[tuple[int, int]], dict]:
    """
    Demo:
    >>> s = "Athens Greece Beijing China Athens Greece Berlin Germany"

    Returns:
        - >>> [(5, 0), (5, 1), ..., (2, 4)]
        - >>> {'Athens': 0, 'Beijing': 1, ..., 'Greece': 5}
    """
    tokens = []
    with open(dataset_path, mode='r', encoding='utf-8') as f:
        for line in f:
            tokens.extend(line.strip().split())
    words = set(tokens)
    vocabulary_index = dict(map(lambda x: (x[1], x[0]), enumerate(words)))

    L = []
    for i in range(window_size, len(tokens) - window_size, 1):
        left_context = tokens[(i - window_size) : i]
        right_context = tokens[(i + 1) : (i + 1 + window_size)]
        for j in range(0, window_size, 1):
            L.append((vocabulary_index.get(tokens[i]), vocabulary_index.get(left_context[j])))
            L.append((vocabulary_index.get(tokens[i]), vocabulary_index.get(right_context[j])))

    return L, vocabulary_index



if __name__ == '__main__':
    window_size = 3     # 观察 questions-words 数据集特点, 建议滑动窗口大小预设 3 或 4.
    m = 3               # 表示单词所需要的维度个数.
    batch_size = 250    # CPU 或 GPU 一次性处理的数据量, 量越多速度越快, 但内(显)存开销也越大.
    L, vocabulary_index = tokenizer('./datasets/capital-country.txt', window_size)
    n = len(vocabulary_index)   # 词汇索引表大小
    epoch = 500         # 迭代次数.

    device = torch.device(
        'mps' if platform.system() == 'Darwin'
        else ('cuda' if torch.cuda.is_available() else 'cpu')
    )

    model = SkipGram(n=n, m=m).to(device)
    criterion = torch.nn.NLLLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

    # 训练词嵌入矩阵.
    for _ in range(0, epoch, 1):
        iterator = iter(L)
        loss: int = 0
        while True:
            # 由于 (中心词, 上下文单词) 元组个数过多, 采用迭代器节约内存.
            batch = list(itertools.islice(iterator, batch_size))
            if not batch:
                break
            x = torch.LongTensor(list(map(lambda t: t[0], batch))).to(device)
            target = torch.LongTensor(list(map(lambda t: t[1], batch))).to(device)
            y = model.forward(x)
            loss: torch.Tensor = loss + criterion.forward(y, target)
        if _ % 25 == 0:
            print(f'[{_ + 25} / {epoch}]\tloss = {loss:.7f}')
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    # 预测训练好的模型效果.
    test = ['Athens', 'Greece', 'Tokyo', 'France', 'London', 'Egypt', 'China']

    index_vocabulary = dict(map(lambda x: (x[0], x[1]), enumerate(vocabulary_index)))
    y: torch.Tensor = model(torch.LongTensor(list(map(lambda x: vocabulary_index.get(x), test))).to(device))
    predict = y.argmax(dim=1, keepdim=False).tolist()
    print('-' * 50)
    for idx, value in enumerate(test):
        print(value, ' ==> ', index_vocabulary.get(predict[idx]))

    # 训练好的词嵌入矩阵.
    C, hidden, output = model.parameters()
    C = C.tolist()

    # 如果词向量维度为 2 则绘制 2D 图像.
    if m == 2:
        plt.scatter(C[vocabulary_index.get('Athens')][0], C[vocabulary_index.get('Athens')][1], marker=',', s=100, label='Athens')
        plt.scatter(C[vocabulary_index.get('Beijing')][0], C[vocabulary_index.get('Beijing')][1], marker='o', s=100, label='Beijing')
        plt.scatter(C[vocabulary_index.get('Berlin')][0], C[vocabulary_index.get('Berlin')][1], marker='x', s=100, label='Berlin')
        plt.scatter(C[vocabulary_index.get('China')][0], C[vocabulary_index.get('China')][1], marker='*', s=100, label='China')
        plt.scatter(C[vocabulary_index.get('Germany')][0], C[vocabulary_index.get('Germany')][1], marker='D', s=100, label='Germany')
        plt.scatter(C[vocabulary_index.get('Greece')][0], C[vocabulary_index.get('Greece')][1], marker='>', s=100, label='Greece')

        plt.plot([C[vocabulary_index.get('Beijing')][0], C[vocabulary_index.get('China')][0]], [C[vocabulary_index.get('Beijing')][1], C[vocabulary_index.get('China')][1]], linestyle='--')
        plt.plot([C[vocabulary_index.get('Athens')][0], C[vocabulary_index.get('Greece')][0]], [C[vocabulary_index.get('Athens')][1], C[vocabulary_index.get('Greece')][1]], linestyle='-.')
        plt.plot([C[vocabulary_index.get('Berlin')][0], C[vocabulary_index.get('Germany')][0]], [C[vocabulary_index.get('Berlin')][1], C[vocabulary_index.get('Germany')][1]], linestyle='-')

        plt.legend()
        plt.show()
    # 如果词向量维度为 3 则绘制 3D 图像.
    elif m == 3:
        ax = plt.figure().add_subplot(projection='3d')

        ax.scatter(C[vocabulary_index.get('Athens')][0], C[vocabulary_index.get('Athens')][1], C[vocabulary_index.get('Athens')][2], marker=',', s=100, label='Athens')
        ax.scatter(C[vocabulary_index.get('Beijing')][0], C[vocabulary_index.get('Beijing')][1], C[vocabulary_index.get('Beijing')][2], marker='o', s=100, label='Beijing')
        ax.scatter(C[vocabulary_index.get('Berlin')][0], C[vocabulary_index.get('Berlin')][1], C[vocabulary_index.get('Berlin')][2], marker='x', s=100, label='Berlin')
        ax.scatter(C[vocabulary_index.get('China')][0], C[vocabulary_index.get('China')][1], C[vocabulary_index.get('China')][2], marker='*', s=100, label='China')
        ax.scatter(C[vocabulary_index.get('Germany')][0], C[vocabulary_index.get('Germany')][1], C[vocabulary_index.get('Germany')][2], marker='D', s=100, label='Germany')
        ax.scatter(C[vocabulary_index.get('Greece')][0], C[vocabulary_index.get('Greece')][1], C[vocabulary_index.get('Greece')][2], marker='>', s=100, label='Greece')

        ax.plot3D([C[vocabulary_index.get('Beijing')][0], C[vocabulary_index.get('China')][0]], [C[vocabulary_index.get('Beijing')][1], C[vocabulary_index.get('China')][1]], [C[vocabulary_index.get('Beijing')][2], C[vocabulary_index.get('China')][2]], linestyle='--')
        ax.plot3D([C[vocabulary_index.get('Athens')][0], C[vocabulary_index.get('Greece')][0]], [C[vocabulary_index.get('Athens')][1], C[vocabulary_index.get('Greece')][1]], [C[vocabulary_index.get('Athens')][2], C[vocabulary_index.get('Greece')][2]], linestyle='-.')
        ax.plot3D([C[vocabulary_index.get('Berlin')][0], C[vocabulary_index.get('Germany')][0]], [C[vocabulary_index.get('Berlin')][1], C[vocabulary_index.get('Germany')][1]], [C[vocabulary_index.get('Berlin')][2], C[vocabulary_index.get('Germany')][2]], linestyle='-')

        ax.xaxis._axinfo['grid']['color'] = (0.5, 0.5, 0.5, 0.25)
        ax.yaxis._axinfo['grid']['color'] = (0.5, 0.5, 0.5, 0.25)
        ax.zaxis._axinfo['grid']['color'] = (0.5, 0.5, 0.5, 0.25)

        plt.legend()
        plt.show()
    # 如果词向量是高纬度, 呃呃呃, 画不出来...
    else:
        ...