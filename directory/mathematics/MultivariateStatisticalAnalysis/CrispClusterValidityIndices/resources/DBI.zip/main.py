'''
System --> MacOS & Python 3.10.0
File ----> main.py
Author --> Illusionna
Create --> 2024-10-10 19:58:05
Website -> https://orzzz.net
'''

import os
import ctypes
import platform


def cls() -> None:
    os.system('')
    try:
        os.system(
            {'Windows': 'cls', 'Linux': 'clear', 'Darwin': 'clear'}[platform.system()]
        )
    except:
        print('\033[H\033[J', end='')
cls()


def Accelerate(func: 'function') -> 'function':
    """
    C 语言加速计算装饰器函数.
    """
    try:
        OS = {
            'Darwin': 'dylib',
            'Linux': 'so',
            'Windows': 'dll'
        }[platform.system()]
        try:
            lib = ctypes.CDLL(f'./utils/DBI.{OS}')
        except:
            os.system(f'gcc --shared -o ./utils/DBI.{OS} ./utils/DBI.c')
            lib = ctypes.CDLL(f'./utils/DBI.{OS}')
    except:
        try:
            lib = ctypes.CDLL(f'./utils/DBI.so')
        except:
            os.system(f'gcc --shared -o ./utils/DBI.so ./utils/DBI.c')
            lib = ctypes.CDLL(f'./utils/DBI.so')
    lib.__getattr__('EuclideanDistance')
    lib.__getattr__('Centroid')
    lib.__getattr__('Cohesion')
    lib.EuclideanDistance.argtypes = [
        ctypes.POINTER(ctypes.c_double),
        ctypes.POINTER(ctypes.c_double),
        ctypes.c_int
    ]
    lib.EuclideanDistance.restype = ctypes.c_double
    lib.Centroid.argtypes = [
        ctypes.POINTER(ctypes.POINTER(ctypes.c_double)),
        ctypes.c_int,
        ctypes.c_int
    ]
    lib.Centroid.restype = ctypes.POINTER(ctypes.c_double)
    lib.Cohesion.argtypes = [
        ctypes.POINTER(ctypes.POINTER(ctypes.c_double)),
        ctypes.c_int,
        ctypes.c_int
    ]
    lib.Cohesion.restype = ctypes.c_double
    # ------------------------------------------
    def Wrapper(*args, **kwargs) -> float:
        kwargs.update({'lib': lib})
        return func(*args, **kwargs)
    # ------------------------------------------
    return Wrapper


def MinkowskiDistance(a: list, b: list, p: int = 2, lib: ctypes.CDLL = None) -> float:
    """
    计算闵可夫斯基距离, 默认 p 指数为 2, 退化为欧几里得距离.
    >>> a = [1, 2, 3]
    >>> b = [4, 5, 6]
    >>> MinkowskiDistance(a, b, 1)
    """
    if lib:
        size = len(a)
        return lib.EuclideanDistance(
            (ctypes.c_double * size)(*a),
            (ctypes.c_double * size)(*b),
            size
        )
    return sum([abs(i - j) ** p for i, j in zip(a, b)]) ** (1 / p)


def Centroid(C: list[list], lib: ctypes.CDLL = None) -> list:
    """
    计算簇的质心向量, 即重心, 其中 C 是某一个簇, 即二层嵌套列表.
    >>> C = [
        [5.1, 3.5, 1.4, 0.2],
        [4.9, 3.0, 1.4, 0.2],
        [5.0, 3.3, 1.4, 0.2]
    ]
    >>> Centroid(C)
    """
    if lib:
        arrs = (ctypes.POINTER(ctypes.c_double) * len(C))()
        for i, row in enumerate(C):
            arrs[i] = ctypes.cast(
                (ctypes.c_double * len(row))(*row),
                ctypes.POINTER(ctypes.c_double)
            )
        centroid = lib.Centroid(arrs, len(C), len(C[0]))
        return [centroid[i] for i in range(0, len(C[0]), 1)]
    return list(map(lambda c: sum(c) / len(c), zip(*C)))


def Cohesion(C: list[list], lib: ctypes.CDLL = None) -> float:
    """
    计算簇的凝聚力, 即簇内所有点到重心的距离, 其中 C 是二层嵌套列表.
    >>> C = [
        [5.1, 3.5, 1.4, 0.2],
        [4.9, 3.0, 1.4, 0.2],
        [5.0, 3.3, 1.4, 0.2]
    ]
    >>> Cohesion(C)
    """
    if lib:
        rows = len(C)
        cols = len(C[0])
        arrs = (ctypes.POINTER(ctypes.c_double) * rows)()
        for i, row in enumerate(C):
            arrs[i] = ctypes.cast(
                (ctypes.c_double * len(row))(*row),
                ctypes.POINTER(ctypes.c_double)
            )
        return lib.Cohesion(arrs, rows, cols)
    centroid = Centroid(C)
    return sum(MinkowskiDistance(c, centroid) for c in C) / len(C)


# 使用 C 语言加速计算装饰器.
@Accelerate
def DaviesBouldinIndex(C: list[list[list]], lib: ctypes.CDLL = None) -> float:
    """
    计算 DBI 聚类指数, 其中 C 是三层嵌套列表.
    >>> C = [
                [
                    [5.1, 3.5, 1.4, 0.2],
                    [4.9, 3.0, 1.4, 0.2],
                    [5.0, 3.3, 1.4, 0.2]
                ],
                [
                    [4.9, 2.4, 3.3, 1.0],
                    [6.6, 2.9, 4.6, 1.3]
                ],
                [
                    [6.5, 3.0, 5.5, 1.8],
                    [7.7, 3.8, 6.7, 2.2],
                    [7.2, 3.2, 6.0, 1.8],
                    [6.4, 2.8, 5.6, 2.1]
                ]
            ]
    >>> DaviesBouldinIndex(C)
    """
    return sum(
        max(
            (Cohesion(Ci, lib) + Cohesion(Cj, lib)) / MinkowskiDistance(Centroid(Ci, lib), Centroid(Cj, lib), p=2, lib=lib) for Cj in C if Ci != Cj
        )
        for Ci in C
    ) / len(C)



if __name__ == '__main__':
    C = [
        [[5.1, 3.5, 1.4, 0.2],
         [4.9, 3.0, 1.4, 0.2],
         [5.0, 3.3, 1.4, 0.2]],

        [[4.9, 2.4, 3.3, 1.0],
         [6.6, 2.9, 4.6, 1.3]],

        [[6.5, 3.0, 5.5, 1.8],
         [7.7, 3.8, 6.7, 2.2],
         [7.2, 3.2, 6.0, 1.8],
         [6.4, 2.8, 5.6, 2.1]]
    ]
    print(DaviesBouldinIndex(C))