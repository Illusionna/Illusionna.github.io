/*
编译动态链接库或共享对象库
>>> gcc --shared -o ./utils/DBI.so ./utils/DBI.c
>>> gcc --shared -o ./utils/DBI.dll ./utils/DBI.c
>>> gcc --shared -o ./utils/DBI.dylib ./utils/DBI.c
*/

# include <math.h>
# include <stdlib.h>

// 计算欧几里得距离.
double EuclideanDistance(double* a, double* b, int size) {
    double sum = 0;
    for (int i = 0; i < size; ++i) {
        sum = sum + pow(b[i] - a[i], 2);
    }
    return sqrt(sum);
}

// 计算簇的质心.
double* Centroid(double** C, int rows, int cols) {
    double* ans = (double*) malloc(cols * sizeof(double));
    for (int j = 0; j < cols; ++j) {
        double tmp = 0;
        for (int i = 0; i < rows; ++i) {
            tmp = tmp + C[i][j];
        }
        ans[j] = tmp / rows;
    }
    return ans;
}

// 计算簇内所有点到簇心的距离.
double Cohesion(double** C, int rows, int cols) {
    double ans = 0;
    double* centroid = Centroid(C, rows, cols);
    for (int c = 0; c < rows; ++c) {
        ans = ans + EuclideanDistance(C[c], centroid, cols);
    }
    free(centroid);
    return ans / rows;
}